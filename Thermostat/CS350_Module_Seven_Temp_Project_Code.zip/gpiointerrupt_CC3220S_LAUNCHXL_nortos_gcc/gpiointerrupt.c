#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/UART.h>
#include "ti_drivers_config.h"

/* Global Variables */
int setPoint = 25;  // Default set-point temperature
int roomTemp = 0;   // Current room temperature
int heatOn = 0;     // 0 = off, 1 = on
int secondsElapsed = 0;
unsigned int buttonTimer = 0;
unsigned int tempTimer = 0;
unsigned int uartTimer = 0;
volatile unsigned char TimerFlag = 0;

/* Task Timing Intervals */
#define BUTTON_INTERVAL 200
#define TEMP_INTERVAL 500
#define UART_INTERVAL 1000

/* I2C and UART Handles */
I2C_Handle i2c;
UART_Handle uart;
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

/* I2C sensor info */
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

/* Function Prototypes */
void initI2C(void);
void initUART(void);
void initTimer(void);
int16_t readTemp(void);
void sendData(int roomTemp, int setPoint, int heat, int seconds);
void taskScheduler(void);
void gpioButtonFxn0(uint_least8_t index);  // Increase set point
void gpioButtonFxn1(uint_least8_t index);  // Decrease set point
void timerCallback(Timer_Handle myHandle, int_fast16_t status);

/* ======== Main Thread ======== */
void *mainThread(void *arg0)
{
    /* Initialize GPIO, I2C, UART, and Timer */
    GPIO_init();
    initI2C();
    initUART();
    initTimer();

    /* Configure the LED and buttons */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Set up button interrupts */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);  // Increase temperature
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);  // Decrease temperature
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /* Main Task Scheduler Loop */
    while (1)
    {
        if (TimerFlag)
        {
            taskScheduler();
            TimerFlag = 0;
        }
    }
    return (NULL);
}

/* ======== I2C Initialization ======== */
void initI2C(void)
{
    I2C_Params i2cParams;
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);

    int8_t i, found = 0;
    txBuffer[0] = 0;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    for (i = 0; i < 3; i++) {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;

        if (I2C_transfer(i2c, &i2cTransaction)) {
            found = 1;
            break;
        }
    }

    if (!found) {
        // Handle the case where no sensor is found
        while (1);  // You can add error handling here
    }
}

/* ======== UART Initialization ======== */
void initUART(void)
{
    UART_Params uartParams;
    UART_init();
    UART_Params_init(&uartParams);
    uartParams.baudRate = 115200;
    uart = UART_open(CONFIG_UART_0, &uartParams);
}

/* ======== Timer Initialization ======== */
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 200000;  // 200 ms period
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    Timer_start(timer0);
}

/* ======== Temperature Reading via I2C ======== */
int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction)) {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;  // Convert to degrees Celsius
    }
    return temperature;
}

/* ======== UART Data Transmission ======== */
void sendData(int roomTemp, int setPoint, int heat, int seconds)
{
    char output[64];
    snprintf(output, sizeof(output), "<%02d,%02d,%d,%04d>", roomTemp, setPoint, heat, seconds);
    UART_write(uart, output, strlen(output));
}

/* ======== Timer Callback ======== */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}

/* ======== Task Scheduler ======== */
void taskScheduler(void)
{
    static unsigned int timeElapsed = 0;
    timeElapsed += 200;  // Timer fires every 200 ms

    if (timeElapsed - buttonTimer >= BUTTON_INTERVAL)
    {
        buttonTimer = timeElapsed;
        // Button press handled by interrupts
    }

    if (timeElapsed - tempTimer >= TEMP_INTERVAL)
    {
        tempTimer = timeElapsed;
        roomTemp = readTemp();  // Read temperature from sensor
    }

    if (timeElapsed - uartTimer >= UART_INTERVAL)
    {
        uartTimer = timeElapsed;
        secondsElapsed++;
        if (roomTemp < setPoint)
        {
            heatOn = 1;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Heater on
        }
        else
        {
            heatOn = 0;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Heater off
        }
        sendData(roomTemp, setPoint, heatOn, secondsElapsed);
    }
}

/* ======== Button Interrupt Handlers ======== */
void gpioButtonFxn0(uint_least8_t index)  // Increase set point
{
    setPoint++;
}

void gpioButtonFxn1(uint_least8_t index)  // Decrease set point
{
    setPoint--;
}
